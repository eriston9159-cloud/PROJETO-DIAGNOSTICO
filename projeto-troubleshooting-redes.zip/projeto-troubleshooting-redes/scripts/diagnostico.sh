#!/bin/bash
# Diagnostico rapido de rede (Linux/macOS) - salva em diagnostico.txt
OUT=diagnostico.txt
{
echo "===== DIAGNOSTICO DE REDE ====="
echo "--- interfaces ---";   ip a 2>/dev/null || ifconfig
echo "--- rotas ---";        ip route 2>/dev/null || netstat -rn
echo "--- ping loopback ---"; ping -c 2 127.0.0.1
echo "--- ping 8.8.8.8 ---";  ping -c 4 8.8.8.8
echo "--- ping google.com ---"; ping -c 4 google.com
echo "--- nslookup ---";     nslookup google.com
echo "--- traceroute ---";   traceroute -m 10 8.8.8.8
echo "--- arp ---";          arp -a
} > "$OUT" 2>&1
echo "Resultado salvo em $OUT"
