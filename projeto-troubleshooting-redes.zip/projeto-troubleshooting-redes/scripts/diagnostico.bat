@echo off
REM Diagnostico rapido de rede (Windows) - salva resultado em diagnostico.txt
set OUT=diagnostico.txt
echo ===== DIAGNOSTICO DE REDE ===== > %OUT%
echo --- ipconfig /all --- >> %OUT%
ipconfig /all >> %OUT%
echo --- ping loopback --- >> %OUT%
ping -n 2 127.0.0.1 >> %OUT%
echo --- ping 8.8.8.8 --- >> %OUT%
ping -n 4 8.8.8.8 >> %OUT%
echo --- ping google.com --- >> %OUT%
ping -n 4 google.com >> %OUT%
echo --- nslookup --- >> %OUT%
nslookup google.com >> %OUT%
echo --- tracert --- >> %OUT%
tracert -d -h 10 8.8.8.8 >> %OUT%
echo --- arp -a --- >> %OUT%
arp -a >> %OUT%
echo Resultado salvo em %OUT%
pause
