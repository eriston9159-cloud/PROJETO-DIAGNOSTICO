# Prints dos testes

Salve aqui as capturas de tela dos testes, com a nomenclatura:

| Arquivo | Conteúdo |
|---------|----------|
| `01-sem-internet-ping-tracert.png` | ping gateway/8.8.8.8 e tracert |
| `02-ip-incorreto-ipconfig.png` | ipconfig /all com IP 169.254.x.x ou incorreto |
| `03-dns-nslookup.png` | nslookup falhando e funcionando após correção |
| `04-cabo-midia-desconectada.png` | ipconfig mostrando "Mídia desconectada" |
| `05-conflito-arp.png` | arp -a e aviso de conflito |

Depois de cada print, referencie no documento correspondente com:
`![descrição](../imagens/nome-do-arquivo.png)`
