# Projeto: Troubleshooting de Redes de Computadores

Simulação e diagnóstico de **5 situações comuns** encontradas em redes locais, com descrição do problema, causas prováveis, comandos de diagnóstico e solução.

## Objetivo
Desenvolver a capacidade de **identificar, analisar e solucionar** problemas comuns de redes, usando procedimentos e ferramentas de diagnóstico.

## Estrutura do repositório

```
projeto-troubleshooting-redes/
├── README.md                       # Este arquivo
├── docs/
│   ├── 00-metodologia-e-comandos.md  # Método e referência dos comandos
│   ├── 01-sem-acesso-internet.md
│   ├── 02-ip-incorreto.md
│   ├── 03-problema-dns.md
│   ├── 04-cabo-desconectado.md
│   └── 05-conflito-ip.md
├── scripts/
│   ├── diagnostico.bat             # Diagnóstico rápido (Windows)
│   └── diagnostico.sh              # Diagnóstico rápido (Linux/macOS)
└── imagens/                        # Prints dos testes (ver imagens/README.md)
```

## Situações analisadas

| # | Situação | Sintoma principal | Documento |
|---|----------|-------------------|-----------|
| 1 | Computador sem acesso à internet | Navegador sem carregar páginas | [01](docs/01-sem-acesso-internet.md) |
| 2 | Endereço IP incorreto | IP 169.254.x.x ou fora da faixa da rede | [02](docs/02-ip-incorreto.md) |
| 3 | Problema de DNS | Ping por IP funciona, por nome não | [03](docs/03-problema-dns.md) |
| 4 | Cabo desconectado/defeituoso | "Cabo de rede desconectado", link apagado | [04](docs/04-cabo-desconectado.md) |
| 5 | Conflito de endereço IP | Aviso de IP duplicado, conexão intermitente | [05](docs/05-conflito-ip.md) |

## Ferramentas utilizadas
`ipconfig` / `ip`, `ping`, `tracert` / `traceroute`, `nslookup`, `arp`, `netstat`, `route`, `nbtstat`, além de verificação física (LEDs, cabos, switch/roteador).

## Método geral de diagnóstico (de baixo para cima)
1. **Física** – cabo, LEDs, Wi-Fi ligado
2. **IP local** – `ipconfig /all`
3. **Gateway** – `ping <gateway>`
4. **Internet por IP** – `ping 8.8.8.8`
5. **DNS** – `ping google.com` / `nslookup`

Detalhes em [docs/00-metodologia-e-comandos.md](docs/00-metodologia-e-comandos.md).

## Como reproduzir os testes
Execute os comandos de cada documento em um laboratório (máquinas virtuais ou rede doméstica de testes) e salve os prints na pasta `imagens/`, seguindo a nomenclatura descrita lá.

## Autor
*(Seu nome, turma e data)*
