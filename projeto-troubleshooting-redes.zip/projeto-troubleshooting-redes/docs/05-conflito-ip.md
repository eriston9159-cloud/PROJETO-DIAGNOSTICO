# 5. Conflito de endereço IP

## O que está acontecendo
Aparece o aviso **"Há um conflito de endereço IP"** (ou "Another computer on this network has the same IP address"). A conexão fica intermitente ou um dos dispositivos perde a rede.

## Possíveis causas
- Dois dispositivos com o mesmo IP fixo
- IP fixo dentro do pool do DHCP
- Dois servidores DHCP na rede (ex.: roteador extra ligado errado)
- Máquina voltando de suspensão com IP antigo

## Diagnóstico
```
ipconfig /all          # anote seu IP e MAC
arp -a                 # veja qual MAC está associado ao IP em disputa
ping <IP em conflito>  # identifica se outro host responde
nbtstat -a <IP>        # descobre o nome/MAC do outro dispositivo
```
Se, com a sua máquina desconectada, o IP ainda responde, existe outro dispositivo usando-o. O MAC no `arp -a` permite localizá-lo.

## Solução
1. Alterar o IP de um dos dispositivos (fora do pool DHCP) ou usar DHCP.
2. `ipconfig /release` → `ipconfig /renew`
3. Criar **reserva de DHCP** (IP fixo por MAC) no roteador para equipamentos importantes.
4. Remover servidores DHCP duplicados.
5. Documentar a faixa de IPs fixos e a faixa dinâmica.
