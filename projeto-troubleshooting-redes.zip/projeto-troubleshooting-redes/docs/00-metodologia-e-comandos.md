# Metodologia e Referência de Comandos

## Fluxo de diagnóstico

```
Cabo/Wi-Fi OK? → IP válido? → Gateway responde? → Internet por IP? → DNS resolve?
     (1)             (2)            (3)                 (4)               (5)
```
O primeiro passo que **falhar** indica a camada do problema.

## Comandos

| Comando | Sistema | Finalidade |
|---------|---------|------------|
| `ipconfig /all` | Windows | Mostra IP, máscara, gateway, DNS, MAC e se o DHCP está ativo |
| `ip a` / `ip addr` | Linux | Equivalente ao ipconfig |
| `ipconfig /release` e `/renew` | Windows | Libera e solicita novo IP ao DHCP |
| `ipconfig /flushdns` | Windows | Limpa o cache de DNS |
| `ping <destino>` | Todos | Testa conectividade (ICMP) e mede latência/perda |
| `tracert <destino>` | Windows | Mostra os saltos (roteadores) até o destino e onde para |
| `traceroute <destino>` | Linux | Idem |
| `nslookup <nome>` | Todos | Consulta DNS e mostra qual servidor respondeu |
| `arp -a` | Todos | Lista a tabela IP ↔ MAC (útil para achar conflitos) |
| `route print` / `ip route` | Win / Linux | Exibe a tabela de rotas e o gateway padrão |
| `netstat -an` | Todos | Lista conexões e portas em uso |
| `nbtstat -a <IP>` | Windows | Identifica o nome/MAC de um host na rede |

## Interpretação rápida do `ping`
- **Resposta de ...**: conectividade OK.
- **Esgotado o tempo limite (Request timed out)**: pacote perdido ou bloqueado.
- **Host de destino inacessível**: sem rota para o destino.
- **Falha geral / could not find host**: problema de DNS ou de rede local.
