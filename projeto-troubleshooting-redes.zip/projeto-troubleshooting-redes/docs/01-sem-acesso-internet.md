# 1. Computador sem acesso à internet

## O que está acontecendo
O usuário abre o navegador e as páginas não carregam. O computador pode até estar "conectado" à rede local.

## Possíveis causas
- Roteador/modem sem sinal do provedor (ISP)
- Gateway padrão incorreto ou ausente
- Falha de DHCP
- DNS indisponível
- Cabo ou Wi-Fi com problema
- Firewall, proxy ou configuração de rede incorreta

## Diagnóstico (passo a passo)

```
ipconfig /all          # IP, gateway e DNS estão preenchidos?
ping 127.0.0.1         # Pilha TCP/IP local funciona?
ping <IP do gateway>   # Alcança o roteador?
ping 8.8.8.8           # Alcança a internet por IP?
ping google.com        # Resolve nomes?
tracert 8.8.8.8        # Em qual salto o caminho para?
```

| Resultado | Conclusão |
|-----------|-----------|
| Gateway não responde | Problema na rede local (cabo, IP, roteador) |
| Gateway responde, 8.8.8.8 não | Problema no roteador/provedor |
| 8.8.8.8 responde, nome não | Problema de DNS (ver doc 03) |

## Solução
1. Reiniciar modem e roteador (30 s desligados).
2. Conferir cabos/Wi-Fi.
3. `ipconfig /release` → `ipconfig /renew`.
4. Corrigir gateway/DNS ou voltar para "Obter IP automaticamente".
5. Se só o roteador responde, contatar o provedor.
