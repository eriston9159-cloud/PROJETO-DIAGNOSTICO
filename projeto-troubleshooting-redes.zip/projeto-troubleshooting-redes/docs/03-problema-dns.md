# 3. Problema de DNS

## O que está acontecendo
O computador acessa a internet **por IP** (ex.: `ping 8.8.8.8` funciona), mas não abre sites por nome. O navegador mostra "Não foi possível encontrar o servidor / DNS_PROBE_FINISHED_NO_INTERNET".

## Possíveis causas
- Servidor DNS configurado incorreto ou fora do ar
- Cache DNS corrompido
- Roteador com DNS defeituoso
- Arquivo `hosts` alterado
- Bloqueio por firewall (porta 53)

## Diagnóstico
```
ping 8.8.8.8          # funciona → internet OK
ping google.com       # falha → suspeita de DNS
nslookup google.com   # mostra o servidor DNS usado e se houve resposta
nslookup google.com 8.8.8.8   # testa usando outro DNS
ipconfig /all         # confere os servidores DNS configurados
```
Se `nslookup` com 8.8.8.8 funciona e com o DNS atual não, o DNS configurado é o culpado.

## Solução
1. Limpar o cache: `ipconfig /flushdns`
2. Trocar o DNS para um público: `8.8.8.8` e `8.8.4.4` (Google) ou `1.1.1.1` (Cloudflare)
3. Reiniciar o roteador
4. Verificar o arquivo `C:\Windows\System32\drivers\etc\hosts`
5. Renovar a configuração: `ipconfig /release` e `/renew`
