# 2. Endereço IP incorreto

## O que está acontecendo
A máquina possui um IP que não pertence à rede (ex.: configurado manualmente errado) ou recebeu um IP **APIPA (169.254.x.x)**, indicando que não encontrou servidor DHCP.

## Possíveis causas
- IP/máscara/gateway digitados manualmente com erro
- Servidor DHCP desligado ou sem endereços disponíveis
- Cabo/Wi-Fi com falha impedindo contato com o DHCP
- Máquina em VLAN/rede errada

## Diagnóstico
```
ipconfig /all
```
Verifique:
- IPv4 na mesma faixa do gateway (ex.: IP `192.168.1.25`, gateway `192.168.1.1`, máscara `255.255.255.0`)
- "DHCP habilitado: Sim/Não"
- Endereço `169.254.x.x` = falha de DHCP

```
ping <gateway>
```
Sem resposta com IP fora da faixa confirma o erro de endereçamento.

## Solução
**Se o IP foi configurado manualmente:** corrigir para a faixa correta ou escolher *Obter endereço IP automaticamente* (Painel de Controle → Adaptador → Propriedades → IPv4).

**Se veio 169.254.x.x:**
```
ipconfig /release
ipconfig /renew
```
Se persistir: verificar cabo, reiniciar roteador/servidor DHCP e conferir o pool de endereços.
