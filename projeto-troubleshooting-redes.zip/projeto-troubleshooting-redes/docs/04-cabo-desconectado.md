# 4. Cabo de rede desconectado ou com defeito

## O que está acontecendo
O ícone de rede mostra um "X" vermelho e a mensagem **"Cabo de rede desconectado"**, ou a conexão cai e volta, fica lenta ou negocia velocidade baixa (10 Mbps).

## Possíveis causas
- Cabo solto ou rompido
- Conector RJ-45 mal crimpado ou oxidado
- Porta do switch/roteador/placa de rede com defeito
- Cabo longo demais (>100 m) ou interferência
- Placa de rede desabilitada

## Diagnóstico
**Verificação física**
- LEDs da placa e da porta do switch (apagados = sem link)
- Trocar o cabo por um comprovadamente bom
- Testar outra porta do switch
- Usar testador de cabos, se disponível

**Por comandos**
```
ipconfig /all     # "Mídia desconectada" confirma falta de link
ip link show      # Linux: estado "NO-CARRIER" / "DOWN"
ping <gateway>    # sem resposta
```
Também verificar no Gerenciador de Dispositivos se o adaptador está habilitado.

## Solução
1. Reconectar firmemente as duas pontas.
2. Substituir o cabo ou refazer o conector RJ-45.
3. Trocar a porta do switch.
4. Habilitar/reinstalar o driver da placa de rede.
5. Se nada funcionar, trocar a placa de rede (ou usar adaptador USB).
